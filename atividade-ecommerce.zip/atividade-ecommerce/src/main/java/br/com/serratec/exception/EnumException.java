package br.com.serratec.exception;

public class EnumException extends RuntimeException{

    public EnumException(String message) {
        super(message);

    }

}
