package br.com.serratec.dto;


//Requisição | Pergunta
//DTO = Objeto de transferencia de dado | Data transfer object
public class ProdutoRequestDTO {
	
	
//Request existe para pegar as requisições utilizando suas regras de negócio
//Nela por exemplo não precisa setar o ID, pois ele é gerado automáticamente
}
